for((counter = 0; counter < 50; counter++))
do
    ./hello
done