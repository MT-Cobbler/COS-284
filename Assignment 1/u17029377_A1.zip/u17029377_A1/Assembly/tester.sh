for((counter = 0; counter < 5000; counter++))
do
    ./hello
done