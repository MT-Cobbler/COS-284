print('The quick brown fox jumps over the lazy dog.')
