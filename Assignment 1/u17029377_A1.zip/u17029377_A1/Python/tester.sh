for((counter = 0; counter < 50; counter++))
do
    python3 hello.py
done