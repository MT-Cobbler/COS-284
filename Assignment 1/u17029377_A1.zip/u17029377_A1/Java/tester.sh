for((counter = 0; counter < 5000; counter++))
do
    java hello
done